package com.example;

import com.example.clients.Client;
import com.example.employees.*;
import com.example.utils.Utils;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Utils.log("System starting...");

        // Create clients
        List<Client> clients = new ArrayList<>();
        clients.add(new Client(1, "Ahmed", "Hassan", "1990-01-01", "ahmed.hassan@example.com", "Email", "1234567890"));
        clients.add(new Client(2, "Fatima", "Ali", "1985-05-15", "fatima.ali@example.com", "Phone", "0987654321"));

        // Create employees
        List<Employee> employees = new ArrayList<>();
        employees.add(new FullTimeEmployee(1, "Omar", "Khan", "2020-01-01", "omar.khan@example.com", "2019-10-01", 60000));
        employees.add(new PartTimeEmployee(2, "Layla", "Yousef", "2021-06-01", "layla.yousef@example.com", "2020-01-01", 20, 25));
        employees.add(new Trainee(3, "Zain", "Abbas", "2022-03-01", "zain.abbas@example.com", "2025-01-01", 85));

        // Demonstrate functionality
        for (Client client : clients) {
            System.out.println(client.toString());
        }

        for (Employee employee : employees) {
            System.out.println(employee.toString() + " - Salary: " + employee.calculateSalary());
        }

        Utils.log("System stopping...");
    }
}