package com.example.utils;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;

public class Utils {

    private static final String LOG_FILE = "system.log";

    public static void log(String message) {
        try (PrintWriter out = new PrintWriter(new FileWriter(LOG_FILE, true))) {
            out.println(LocalDateTime.now() + ": " + message);
        } catch (IOException e) {
            System.err.println("Error writing to log file: " + e.getMessage());
        }
    }

    public static void logSystemStart() {
        log("System started.");
    }

    public static void logSystemStop() {
        log("System stopped.");
    }

    public static void logException(Exception e) {
        log("Exception occurred: " + e.getMessage());
    }
}
