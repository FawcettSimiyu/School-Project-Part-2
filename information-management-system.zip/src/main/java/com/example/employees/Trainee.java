package com.example.employees;

public class Trainee extends Employee {
    private int score;

    public Trainee(int id, String firstName, String lastName, String dateOfBirth, String email, String dateOfEmployment, int score) {
        super(id, firstName, lastName, dateOfBirth, email, dateOfEmployment);
        this.score = score;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        if (score < 0 || score > 100) {
            throw new IllegalArgumentException("Score must be between 0 and 100.");
        }
        this.score = score;
    }

    @Override
    public double calculateSalary() {
        if (score < 50) {
            return 0; // No salary if score is below 50
        }
        return score * 100; // Example salary calculation based on score
    }
}
