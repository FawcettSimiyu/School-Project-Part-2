package com.example.employees;

public class FullTimeEmployee extends Employee {
    private double fixedSalary;

    public FullTimeEmployee(int id, String firstName, String lastName, String dateOfBirth, String email, String dateOfEmployment, double fixedSalary) {
        super(id, firstName, lastName, dateOfBirth, email, dateOfEmployment);
        this.fixedSalary = fixedSalary;
    }

    @Override
    public double calculateSalary() {
        return fixedSalary;
    }

    public double getFixedSalary() {
        return fixedSalary;
    }

    public void setFixedSalary(double fixedSalary) {
        this.fixedSalary = fixedSalary;
    }
}
