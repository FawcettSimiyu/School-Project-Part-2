package com.example.clients;

public class Client {
    private int id;
    private String firstName;
    private String lastName;
    private String dateOfBirth;
    private String emailAddress;
    private String preferredContactMethod;
    private String phoneNumber;

    public Client(int id, String firstName, String lastName, String dateOfBirth, String emailAddress, String preferredContactMethod, String phoneNumber) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.dateOfBirth = dateOfBirth;
        this.emailAddress = emailAddress;
        this.preferredContactMethod = preferredContactMethod;
        this.phoneNumber = phoneNumber;
    }

    public int getId() {
        return id;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public String getPreferredContactMethod() {
        return preferredContactMethod;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    @Override
    public String toString() {
        return "Client{" +
                "id=" + id +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", dateOfBirth='" + dateOfBirth + '\'' +
                ", emailAddress='" + emailAddress + '\'' +
                ", preferredContactMethod='" + preferredContactMethod + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                '}';
    }
}
