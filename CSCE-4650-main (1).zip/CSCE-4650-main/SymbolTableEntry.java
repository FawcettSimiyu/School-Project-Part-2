// SymbolTableEntry.java

import java.util.*;

public class SymbolTableEntry {
    public enum Category { CLASS, FUNCTION, VARIABLE }

    private Category category;
    private String type; // int, array, object, etc.
    private boolean isStatic;
    private LinkedList<String> argTypes;
    private SymbolTable localEnv;
    private String code = "";

    // Constructors
    public SymbolTableEntry(Category category, String type) {
        this.category = category;
        this.type = type;
    }

    public SymbolTableEntry(Category category, String type, boolean isStatic) {
        this(category, type);
        this.isStatic = isStatic;
    }

    public SymbolTableEntry(Category category, String type, boolean isStatic, LinkedList<String> argTypes, SymbolTable localEnv, String code) {
        this(category, type, isStatic);
        this.argTypes = argTypes;
        this.localEnv = localEnv;
        this.code = code;
    }

    public Category getCategory() { return category; }
    public String getType() { return type; }
    public boolean isStatic() { return isStatic; }
    public LinkedList<String> getArgTypes() { return argTypes; }
    public SymbolTable getLocalEnv() { return localEnv; }
    public String getCode() { return code; }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("%-10s %-6s %-8s", category.name(), isStatic ? "yes" : "no", type));
        return sb.toString();
    }
}
