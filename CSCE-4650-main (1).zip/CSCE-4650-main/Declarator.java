// Declarator.java

public class Declarator {
    private String id;
    private String type;

    public Declarator(String id, String type) {
        this.id = id;
        this.type = type;
    }

    public String id() { return id; }
    public String type() { return type; }
}
