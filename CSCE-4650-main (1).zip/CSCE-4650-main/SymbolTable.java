// SymbolTable.java

import java.util.*;

public class SymbolTable {
    private TreeMap<String, SymbolTableEntry> table = new TreeMap<>();
    private SymbolTable parent;

    public SymbolTable(SymbolTable parent) {
        this.parent = parent;
    }

    public void enterVar(String id, String type, boolean isStatic) {
        table.put(id, new SymbolTableEntry(SymbolTableEntry.Category.VARIABLE, type, isStatic));
    }

    public void enterFunction(String id, String returnType, boolean isStatic,
                               LinkedList<String> argTypes, SymbolTable localEnv, String code) {
        table.put(id, new SymbolTableEntry(SymbolTableEntry.Category.FUNCTION, returnType, isStatic, argTypes, localEnv, code));
    }

    public void enterClass(String id, SymbolTable classEnv) {
        table.put(id, new SymbolTableEntry(SymbolTableEntry.Category.CLASS, " ", false, null, classEnv, ""));
    }

    public SymbolTableEntry lookup(String id) {
        SymbolTableEntry entry = table.get(id);
        return (entry != null) ? entry : (parent != null ? parent.lookup(id) : null);
    }

    public SymbolTable parent() {
        return parent;
    }

    public void print(String name) {
        System.out.println();
        System.out.println("Identifier Table for " + name);
        System.out.println("--------------------------");
        System.out.println();
        System.out.println("Id         Category   Static Type");
        System.out.println("--         --------   ------ ----");

        for (Map.Entry<String, SymbolTableEntry> e : table.entrySet()) {
            System.out.printf("%-10s %s\n", e.getKey(), e.getValue().toString());
        }

        for (Map.Entry<String, SymbolTableEntry> e : table.entrySet()) {
            if (e.getValue().getCategory() == SymbolTableEntry.Category.FUNCTION && e.getValue().getLocalEnv() != null) {
                e.getValue().getLocalEnv().print(e.getKey());
            } else if (e.getValue().getCategory() == SymbolTableEntry.Category.CLASS && e.getValue().getLocalEnv() != null) {
                e.getValue().getLocalEnv().print(e.getKey());
            }
        }
    }
}
