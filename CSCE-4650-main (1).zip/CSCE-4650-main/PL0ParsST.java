import java_cup.runtime.*;
import java.io.*;

public class PL0ParsST {
    public static void main(String[] args) throws IOException {
        System.out.println("Source Program");
        System.out.println("--------------\n");

        try {
            // Create lexer and parser
            TinyCPPLex lexer = new TinyCPPLex(new InputStreamReader(System.in));
            TinyCPPParser parser = new TinyCPPParser(lexer);
            
            // Parse and get result
            parser.parse();
            SymbolTable globalEnv = parser.getSymbolTable();
            
            if (globalEnv != null) {
                globalEnv.print("main");
            } else {
                System.out.println("No symbol table generated");
            }
        } catch (Exception e) {
            System.out.println("Error during parsing: " + e.getMessage());
            e.printStackTrace();
        }
    }
}