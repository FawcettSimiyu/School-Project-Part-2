# CSCE 4650/5650 – Assignment 4  
## PL/0 Symbol Table Construction using CUP and JFlex

---

## Project Overview

This project implements a compiler front-end for a Java-like language using **JFlex** (lexer) and **CUP** (parser). It builds a **three-level symbol table** that captures:

1. **Class-level** symbols  
2. **Function-level** symbols (with argument types, return types, local table, intermediate code)  
3. **Variable-level** symbols (with data types: `int`, `array`, or `object`)

The symbol table is constructed during parsing via **semantic actions** in the CUP grammar and printed in a structured format after parsing.

---

## Project Objectives

- Design symbol table classes supporting hierarchical scope resolution
- Capture classes, functions, variables with metadata (type, static flag, arguments, etc.)
- Integrate semantic actions in CUP to build the symbol table during parsing
- Output the final symbol table for validation and inspection

---

## Project Structure

```
CSCE-4650/
    ├── TinyCPP2.jflex            # JFlex lexer specification
    ├── TinyCPP.cup               # CUP parser grammar with semantic actions
    ├── PL0ParsST.java            # Main driver to run the parser
    ├── SymbolTable.java          # Manages nested symbol tables
    ├── SymbolTableEntry.java     # Holds symbol attributes
    ├── Declarator.java           # Represents ID/type pairs
```

---

## Prerequisites

- Java JDK (≥ 8) – Make sure `java` and `javac` are in your system PATH
- JFlex (v1.8.2 or later)
- CUP (v11b or later)

---

## Build Instructions

> **Windows Note:** Use `;` instead of `:` as classpath separator

### 1. Generate the Lexer with JFlex

```bash
jflex TinyCPP.jflex
```

> This generates the `TinyCPPLexer.java` file

---

### 2. Generate the Parser with CUP

```bash
java -jar java-cup-11b-runtime.jar -parser TinyCPPParser -symbols Symbol TinyCPP.cup
```

> This generates `TinyCPPParser.java` and `Symbol.java`

---

### 3. Compile All Java Files

```bash
javac -cp .;java-cup-11b-runtime.jar *.java
```

> If you're on macOS/Linux, use `:` instead of `;`

---

### 4. Run the Main Driver with Input File

```bash
java -cp .;java-cup-11b-runtime.jar PL0ParsST < proc.pl0
```

---

## Expected Output Format

```
Identifier Table for main
--------------------------

Id         Category   Static Type
--         --------   ------ ----
Test1      CLASS      
main       FUNCTION   yes    []->void

Identifier Table for Test1
--------------------------

Id         Category   Static Type
--         --------   ------ ----
h          VARIABLE   no     int
i          VARIABLE   no     int
my_list    VARIABLE   no     array (100, int)
...
```

---

## Symbol Table Details

### 🔹 Class Symbols
- Category: `CLASS`
- Holds reference to local symbol table of the class

### 🔹 Function Symbols
- Category: `FUNCTION`
- Static flag: `yes` or `no`
- Return type (e.g., `void`, `int`)
- Argument types (as `LinkedList<String>`)
- Local symbol table (for function scope)
- Intermediate code (empty string for this assignment)

### 🔹 Variable Symbols
- Category: `VARIABLE`
- Type: `int`, `object`, or `array`
- Static flag: `yes` or `no`

---

## Testing

Use the included `proc.pl0` file or create your own PL/0 source file.

Example run:

```bash
java -cp .;java-cup-11b-runtime.jar PL0ParsST < proc.pl0
```

Check the output for correct symbol hierarchy and formatting.

---

## Troubleshooting

- ❗ `java not recognized` → Install JDK and add it to your PATH
- ❗ `jflex not recognized` → Use `java -jar jflex-x.y.z.jar TinyCPP2.jflex`
- ❗ CUP errors → Check for syntax or unresolved non-terminals in `.cup` file
- ❗ Missing lexer/parser → Ensure you run both JFlex and CUP generation steps

---