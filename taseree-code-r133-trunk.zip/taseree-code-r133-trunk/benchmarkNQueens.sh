mvn exec:java -Dexec.mainClass="org.drools.solver.examples.nqueens.app.NQueensBenchmarkApp"
