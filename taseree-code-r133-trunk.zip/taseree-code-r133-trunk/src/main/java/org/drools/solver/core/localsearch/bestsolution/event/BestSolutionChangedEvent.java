package org.drools.solver.core.localsearch.bestsolution.event;

/**
 * @author Geoffrey De Smet
 */
public class BestSolutionChangedEvent {

}
