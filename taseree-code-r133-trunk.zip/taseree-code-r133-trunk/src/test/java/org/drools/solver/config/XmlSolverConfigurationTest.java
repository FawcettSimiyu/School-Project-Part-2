package org.drools.solver.config;

import junit.framework.TestCase;
import org.drools.solver.core.Solver;

/**
 * @author Geoffrey De Smet
 */
public class XmlSolverConfigurationTest extends TestCase {

    public void testBuildSolver() {
        XmlSolverConfigurer configurer = new XmlSolverConfigurer();
        configurer.configure("/org/drools/solver/config/XmlSolverConfigurationTest.xml");
        Solver solver = configurer.buildSolver();
        assertNotNull(solver);
    }

}
