It's now called drools-solver and part of the JBoss Drools:
website: http://labs.jboss.com/drools/
svn: https://svn.labs.jboss.com/labs/jbossrules/trunk
